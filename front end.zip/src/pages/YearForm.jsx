import React, { useState } from 'react'

import YearServices from '../services/YearServices';
import { useNavigate } from 'react-router-dom';

function YearForm() {


  const navigate = useNavigate();

    const[year,setyear] = useState();

    const handleSubmit = (event) => {
        event.preventDefault();

        const requestData = {
            year:year,
            
        };
    YearServices.createYear(requestData).then(res => {
      alert("Data Added Successfully!  ");
      navigate('/');
  }).catch(err => console.log(err));
}
  return (
    <div>
        
      <div className="container-fluid py-5 h-50">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div className="col-12 col-md-8">
            <div className="card" style={{ borderRadius: "1rem" }}>
              <div className="card-body p-5 text-center">
                <h3 className="mb-5">YEAR FORM</h3>

                <form onSubmit={handleSubmit} >
                <div className="form-floating mb-3">
                  <input
                    type="text"
                    className="form-control"
                    name="formId1"
                    id="formId1"
                    placeholder="name"
                    value={year}
                        onChange={event => setyear(event.target.value)}
                  />
                  <label htmlFor="formId1">YearName</label>
                </div>

                

                <div className="row">
                  <div className="col justify-content-start">
                    <input
                      type="submit"
                      value="Submit"
                      className="btn  w-25 btn-outline-primary float-start"
                    />
                  </div>
                  
                </div>
                </form>

               
              </div>
            </div>
          </div>
        </div>
      </div>
   
    </div>
  )
}
export default YearForm