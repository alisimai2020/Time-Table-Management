import { FormControl, FormGroup, Input, InputLabel, TextField } from '@mui/material'
import { makeStyles } from '@mui/styles';
import React from 'react'

import './form.css';
// const styles = {
//   color: 'blue',
//   fontSize: '16px',
//   fontWeight: 'bold'
// };
function StudentForm() {

  const handleCancel = () => {
    // Handle cancel button click
    console.log('Cancel button clicked');
  };
   
    return (
      <section className="vh-100" style={{ backgroundColor: "#508bfc" }}>
      <div className="container-fluid py-5 h-50">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div className="col-12 col-md-8">
            <div className="card" style={{ borderRadius: "1rem" }}>
              <div className="card-body p-5 text-center">
                <h3 className="mb-5">Sign in</h3>

                <div className="form-floating mb-3">
                  <input
                    type="text"
                    className="form-control"
                    name="formId1"
                    id="formId1"
                    placeholder="name"
                  />
                  <label htmlFor="formId1">Name</label>
                </div>

                <div className="form-floating mb-3">
                  <input
                    type="text"
                    className="form-control"
                    name="formId2"
                    id="formId2"
                    placeholder="password"
                  />
                  <label htmlFor="formId2">Password</label>
                </div>

                <div className="row">
                  <div className="col">
                    <input
                      type="submit"
                      value="Submit"
                      className="btn form-control btn-outline-primary"
                    />
                  </div>
                  <div className="col">
                    <button
                      type="button"
                      className="btn form-control btn-outline-secondary"
                      onClick={handleCancel}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    )
}
export default StudentForm