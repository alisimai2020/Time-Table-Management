import React from 'react'

function TeacherForm() {
  return (
    <div>
      hello teacher
    </div>
  )
}
export default TeacherForm