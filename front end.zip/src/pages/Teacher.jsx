import DepartmentServices from '../services/DepartmentServices';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import ProgramServices from '../services/ProgramServices';
import TeacherServices from '../services/TeacherServices';

function Teacher() {
  const [teacherData, setTeacherData] = useState([]);
  const navigate = useNavigate();
  const [teacherInput, setTeacherInput] = useState('');
  const [editTeacher, setEditTeacherId] = useState(null);
  const [editTeacherValue, setEditTeacherValue] = useState('');

  const [programInput, setProgramInput] = useState('');
  const [programData, setProgramData] = useState([]);

  const [departmentId, setDepartmentId] = useState('');
  const [departments, setDepartments] = useState([]);

  useEffect(() => {
    fetchTeacher();
    fetchProgram();
    fetchDepartment();
  }, []);

  const fetchTeacher = () => {
    TeacherServices.getData()
      .then((response) => {
        setTeacherData(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const fetchProgram = () => {
    ProgramServices.getData()
      .then((response) => {
        setProgramData(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const fetchDepartment = () => {
    DepartmentServices.getData()
      .then((response) => {
        setDepartments(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleAddTeacher = () => {
    setEditTeacherId(null);
    setEditTeacherValue('');
    setTeacherInput('');
    setDepartmentId('');
    setDisplay(true);
  };

  const handleCloseYear = () => {
    setDisplay(false);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (editTeacher) {
      const requestData = {
        teachername: teacherInput,
        department: departmentId,
      };

      TeacherServices.update(editTeacher, requestData)
        .then((res) => {
          navigate('/teacher');
          window.location.reload();
        })
        .catch((err) => console.log(err));
    } else {
      const requestData = {
        teachername: teacherInput,
        department: {
          id: departmentId,
        },
      };

      TeacherServices.create(requestData)
        .then((res) => {
          alert('Data Added Successfully!');
          navigate('/teacher');
          window.location.reload();
        })
        .catch((err) => console.log(err));
    }
  };

  const handleUpdateTeacher = (id, teacher,department) => {
    setEditTeacherId(id);
    setEditTeacherValue(teacher);
    setTeacherInput(teacher);
    setDepartmentId(department);
    setDisplay(true);
  };

  const deletehandleSubmit = (id) => {
    const popMessage = window.confirm('Do you want to delete?');

    if (popMessage) {
      TeacherServices.delete(id)
        .then((res) => {
          navigate('/teacher');
          window.location.reload();
        })
        .catch((err) => console.log(err));
    }
  };

  const [display, setDisplay] = useState(false);

  return (
    <div className="p-5 bg-light">
      <div className="p-1">
        <button onClick={handleAddTeacher} className="btn btn-primary w-25">
          Add Teacher
        </button>

        <table className="table table-striped caption-top bg-white rounded p-4 table-bordered w-75">
          <thead>
            <tr>
              <th>Sno</th>
              <th>teacher</th>
              <th>Department</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {teacherData.length > 0 ? (
              teacherData.map((data, index) => (
                <tr key={data.id}>
                  <td>{index + 1}</td>
                  <td>{data.teachername}</td>
                  <td>{data.department.name}</td>

                  <td>
                    <button
                      onClick={() => handleUpdateTeacher(data.id, data.teachername,data.department)}
                      className="btn btn-sm btn-info ms-1 btn-success"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => deletehandleSubmit(data.id)}
                      className="btn btn-sm btn-danger ms-1 btn-success"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="3">No data available</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {display && (
        <div className="mt-5">
          <div>
            <div className="container-fluid py-5 h-50">
              <div className="row d-flex justify-content-center align-items-center h-100">
                <div className="col-12 col-md-8">
                  <div className="card" style={{ borderRadius: '1rem' }}>
                    <div className="card-body p-5 text-center">
                      <h3 className="mb-5">PROGRAM FORM</h3>
                      <form onSubmit={handleSubmit}>
                        <div className="form-floating mb-3">
                          <input
                            type="text"
                            className="form-control"
                            name="formId1"
                            id="formId1"
                            placeholder="name"
                            value={teacherInput}
                            onChange={(event) => setTeacherInput(event.target.value)}
                          />
                          <label htmlFor="formId1">YearName</label>
                        </div>

                        <div className="form-floating mb-3">
                          <label htmlFor="departmentId">Department:</label>
                          <select
                            id="departmentId"
                            value={departmentId}
                            onChange={(event) => setDepartmentId(event.target.value)}
                           className='form-select'
                          >
                            <option value="{ departmentId ? departmentId.name : ''}">{ departmentId ? departmentId.name : 'Select Department'}</option>
                            {departments.map((department) => (
                              <option key={department.id} value={department.id}>
                                {department.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="row">
                          <div className="col-6 justify-content-start">
                            <button
                              type="submit"
                              className="btn w-25 btn-outline-primary float-start"
                            >
                              {editTeacher ? 'Update' : 'Add'}
                            </button>
                          </div>
                          <div className="col-6 justify-content-start">
                            <button
                              className="btn w-25 btn-outline-danger float-end"
                              onClick={handleCloseYear}
                            >
                              Close
                            </button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Teacher;
