

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
 function Login() {
    const [showRegisterModal, setShowRegisterModal] = useState(false);
    const [loginForm, setLoginForm] = useState({
      email: '',
      password: ''
    });
  
    const handleInputChange = (event) => {
      const { name, value } = event.target;
      setLoginForm({ ...loginForm, [name]: value });
    };
  
    const handleLoginSubmit = (event) => {
      event.preventDefault();
      // Add your login logic here
      console.log('Login form submitted');
    };
  
    const handleRegisterModalOpen = () => {
      setShowRegisterModal(true);
    };
  
    const handleRegisterModalClose = () => {
      setShowRegisterModal(false);
    };
  
    const handleRegisterSubmit = (event) => {
      event.preventDefault();
      // Add your registration logic here
      console.log('Register form submitted');
    };
  
    return (
      
      <section className="vh-100" style={{ backgroundColor: "#508bfc" }}>
      <div className="container-fluid py-5 h-100">
        <div className="row d-flex justify-content-center align-items-center h-100">
        <div className="col-12 col-md-8 col-lg-6 col-xl-5">
            <div className="card" style={{ borderRadius: "1rem" }}>
              <div className="card-body p-5 text-center">
                <h3 className="mb-5">Sign in</h3>

                <div className="form-floating mb-3">
                  <input
                    type="text"
                    className="form-control"
                    name="formId1"
                    id="formId1"
                    placeholder="name"
                  />
                  <label htmlFor="formId1">Name</label>
                </div>

                <div className="form-floating mb-3">
                  <input
                    type="text"
                    className="form-control"
                    name="formId2"
                    id="formId2"
                    placeholder="password"
                  />
                  <label htmlFor="formId2">Password</label>
                </div>

                <div className="row">
                  <div className="col">
                    <input
                      type="submit"
                      value="Submit"
                      className="btn form-control btn-outline-primary mb-5"
                    />
                  </div>
                  
                </div>

                <div className='row'>

                <div className='col-6'>

                <div className="d-grid gap-2">
                        <Link to={'/teacher-create'}
                            className="btn btn-primary mb-3"
                            data-mdb-toggle="pill"
                            href="#pills-teacher"
                            role="tab"
                            aria-controls="pills-login"
                            aria-selected="true"
                            style={{ color: "white", textDecoration: "none" }}
                        >
                            Register Teacher
                        </Link>
                        </div>

                </div>

                <div className='col-6'>

                <div className="d-grid gap-2">
                        <Link to={'/student-create'}
                            className="btn btn-primary mb-3"
                            data-mdb-toggle="pill"
                            href="#pills-student"
                            role="tab"
                            aria-controls="pills-login"
                            aria-selected="true"
                            style={{ color: "white", textDecoration: "none" }}
                        >
                            Register Student
                        </Link>
                        </div>

                </div>
            </div>
                      




              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
      
    );
  };
  
export default Login;

