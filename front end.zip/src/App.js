import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import FooterComponent from './component/FooterComponent';
import HeaderComponent from './component/HeaderComponent';
import Home from './pages/Home';
import EmployeeForm from './pages/employeeForm';
import UpdateEmployee from './pages/updateEmployee';
import SideBar from './component/SideBar/SideBar';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../node_modules/bootstrap/dist/js/bootstrap.min.js';
import Navbar from './component/Navbar/Navbar';
import { useEffect, useState } from 'react';
import Login from './pages/Login';
import StudentForm from './pages/StudentForm';
import TeacherForm from './pages/TeacherForm';
import YearForm from './pages/YearForm';
import YearView from './pages/YearView';
import Role from './pages/Role';
import Department from './pages/Department';
import Program from './pages/Program';
import Teacher from './pages/Teacher';

function App() {
  const [toggle, setToggle] = useState(false);

  function Toggle() {
    setToggle(!toggle);
  }

  useEffect(() => {
    const handleSize = () => {
      if (window.innerWidth > 768) {
        setToggle(false);
      }
    }

    window.addEventListener('resize', handleSize);

    return () => {
      window.removeEventListener('resize', handleSize);
    }
  }, [])

  return (
    <Router>
      <div className="d-flex">
      {!window.location.pathname.includes('/student-create') && (
          <div className={window.location.pathname === '/' ? 'd-none' : toggle ? 'd-none' : 'w-auto position-fixed'}>
            <SideBar />
          </div>
        )}
        

        {!window.location.pathname.includes('/student-create') && (
          <div className={window.location.pathname === '/' ? 'd-none' : toggle ? 'd-none' : 'invisible'}>
            <SideBar />
          </div>
        )}

        <div className='col  overflow-auto'>
        {window.location.pathname !== '/' && window.location.pathname !== '/student-create' && window.location.pathname !== '/teacher-create' && <Navbar Toggle={Toggle} />}
          <Routes>
            <Route exact path='/' element={<Login />} />
            <Route path='/employee' element={<Home />} />
            <Route path='/student-create' element={<StudentForm />} />
            <Route path='/teacher-create' element={<TeacherForm />} />
            <Route path='/teacher' element={<Teacher/>} />
            <Route path='/role' element={<Role />} />
            <Route path='/program' element={<Program />} />
            <Route path='/department' element={<Department />} />
            <Route path='/year-create' element={<YearForm />} />
            <Route path='/create' element={<EmployeeForm />} />
            <Route path='/yearView' element={<YearView />} />
            <Route path="/update/:id" element={<UpdateEmployee />} />
          </Routes>
          
        </div>
      </div>
    </Router>
  );
}

export default App;
