import React,{ useState }  from 'react'
import './sidebar.css'
import 'bootstrap-icons/font/bootstrap-icons.css'

function SideBar() {
    const [active,setActive] = useState(1);
 
      return (

        <div className='Sidebar d-flex justify-content-between flex-column bg-dark py-3 text-white vh-100'>
            <div>

                <a href='' className='head text-white'>
                    <i className='bi bi-code-slash fs-4 me-4'></i>
                    <span className='fs-4'> TIME TABLE MANAGEMENT</span>
                </a>
                <hr className='text-white mt-4' />

                <ul className='nav nav-pills  flex-column  mt-3'>
                    <li className={active===1 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(1)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-speedometer2 fs-4 me-4'></i>
                            <span className='fs-4'> Dashboard</span>
                        </a>
                    </li>
                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Users</strong></span>
                        </a>
                    </li>

                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Class</strong></span>
                        </a>
                    </li>
                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Schedule</strong></span>
                        </a>
                    </li>
                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Course</strong></span>
                        </a>
                    </li>
                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Teacher</strong></span>
                        </a>
                    </li>
                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Year</strong></span>
                        </a>
                    </li>
                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Role</strong></span>
                        </a>
                    </li>

                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Program</strong></span>
                        </a>
                    </li>

                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Student</strong></span>
                        </a>
                    </li>

                    <li className={active===2 ? 'active nav-item p-2':"nav-item p-2"} 
                    onClick={e => setActive(2)}>

                        <a href='' className='p-2 text-white'>
                            <i className='bi bi-people fs-4 me-4'></i>
                            <span className='fs-4'> <strong>Department</strong></span>
                        </a>
                    </li>


                     







                </ul>

            </div>
        </div>
    )
}


export default SideBar