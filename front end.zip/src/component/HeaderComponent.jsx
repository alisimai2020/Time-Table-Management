import React, { Component } from 'react'
import { Header } from 'rsuite'

 class HeaderComponent extends Component {
    constructor(props){
        super(props)

        this.state = {
             
        }
    }

  render() {
    return (
      <div>
            <Header>
                <nav className='navbar navbar-expand-md navbar-dark bg-dark'>
                    <div>
                      <a href='https://javaguides.net' className='navbar-brand'>
                        Employee Management App
                      </a>
                    </div>
                </nav>
            </Header>
      </div>
    )
  }
}
export default HeaderComponent



