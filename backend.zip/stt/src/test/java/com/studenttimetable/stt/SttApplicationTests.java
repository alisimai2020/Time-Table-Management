package com.studenttimetable.stt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SttApplicationTests {

	@Test
	void contextLoads() {
	}

}
