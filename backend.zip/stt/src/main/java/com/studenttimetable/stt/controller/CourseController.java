package com.studenttimetable.stt.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.studenttimetable.stt.modal.Course;
import com.studenttimetable.stt.service.CourseService;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/courses")
public class CourseController {
   
    private CourseService courseService;


            @PostMapping
            public ResponseEntity<Course> createCourse(@RequestBody Course course) {
                Course savedCourse= courseService.createCourses(course);
                return new ResponseEntity<>(savedCourse, HttpStatus.OK);
            }


            @GetMapping
            public List<Course> getAllcourse(){
                return  courseService.getallCourse();

            }


            @GetMapping("/{id}")
            public ResponseEntity<Course>  getCourseyId(@PathVariable Long id) {
                Course course = courseService.getCourseById(id);
                 return new ResponseEntity<>(course, HttpStatus.OK);
            }


            @DeleteMapping("/{id}")
            public ResponseEntity<String> deleteCourse(@PathVariable Long id) {
                courseService.deleteCourse(id);
                return new ResponseEntity<String>("Successfully deleted ", HttpStatus.OK);
            }

        
            @PutMapping("/{id}")
            public ResponseEntity<Course> updateCourse(@PathVariable("id") long id, @RequestBody Course course) {
                course.setId(id);;
                Course courseupdate = courseService.updateClassroom(course);
                return new ResponseEntity<>(courseupdate, HttpStatus.OK);
            }

    
}
