package com.studenttimetable.stt.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.studenttimetable.stt.modal.User;

import com.studenttimetable.stt.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
   

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public User getUserById(Long id) {
        Optional<User> user =userRepository.findById(id);
        return  user.get();
    }

    public List<User> getAllUser() {
        return userRepository.findAll();
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public User updateUser(User user) {
                  User updatesuser = userRepository.findById(user.getId()).get();
                  updatesuser.setUsername(user.getUsername());
                  updatesuser.setPassword(user.getPassword());
                  updatesuser.setStatus(user.getStatus());
                  updatesuser.setRole(user.getRole());
                  return userRepository.save(updatesuser);
    }
   
}
