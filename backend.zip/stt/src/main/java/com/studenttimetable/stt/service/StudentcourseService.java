package com.studenttimetable.stt.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studenttimetable.stt.modal.Course;
import com.studenttimetable.stt.modal.StudentCourse;
import com.studenttimetable.stt.repository.StudentCourseRepository;

@Service
public class StudentcourseService {
   
    // Constructors, getters, and setters
    @Autowired
    private  StudentCourseRepository studentCourseRepository;

    public StudentCourse createCourse(StudentCourse studentprogramcourse) {
        return studentCourseRepository.save(studentprogramcourse);
    }

    public StudentCourse getCourseById(Long id) {
        Optional<StudentCourse> Studentcourse =studentCourseRepository.findById(id);
        return  Studentcourse.get();
    }

    public StudentCourse updateStudentCourse(StudentCourse studentCourse) {
        return studentCourseRepository.save(studentCourse);
    }

    public void deleteCourse(Long id) {
        studentCourseRepository.deleteById(id);
    }

    public List<StudentCourse> getallCourse() {
        return studentCourseRepository.findAll();
    }
}
