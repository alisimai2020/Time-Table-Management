package com.studenttimetable.stt.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.studenttimetable.stt.modal.ClassSchedule;

public interface ClassscheduleRepository extends  JpaRepository<ClassSchedule,Long> {
     
}
