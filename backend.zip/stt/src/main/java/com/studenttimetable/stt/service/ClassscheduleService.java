package com.studenttimetable.stt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studenttimetable.stt.modal.ClassSchedule;
import com.studenttimetable.stt.repository.ClassscheduleRepository;

@Service
public class ClassscheduleService {
   @Autowired
   private ClassscheduleRepository classscheduleRepository;

public ClassSchedule saveSchedule(ClassSchedule classSchedule) {
    return classscheduleRepository.save(classSchedule);
}

public List<ClassSchedule> gettAllSchedule() {
    return classscheduleRepository.findAll();
}

public ClassSchedule gettAllScheduleByID(Long id) {
    Optional<ClassSchedule> classscOptional = classscheduleRepository.findById(id);
    
    return classscOptional.get();
}

public void  deleteSchedule(Long id) {
    classscheduleRepository.deleteById(id);
   
}

public ClassSchedule updateClassSchedule(ClassSchedule classSchedule) {

    ClassSchedule classupdate = classscheduleRepository.findById(classSchedule.getId()).get();

    classupdate.setCourse(classSchedule.getCourse());
    classupdate.setDay(classSchedule.getDay());
    classupdate.setEndTime(classSchedule.getEndTime());
    classupdate.setStartTime(classSchedule.getStartTime());

    return classscheduleRepository.save(classupdate);

    
}

  
}
