package com.studenttimetable.stt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studenttimetable.stt.modal.Student;
import com.studenttimetable.stt.repository.StudentRepository;

@Service
public class studentService {
    @Autowired
    private StudentRepository studentRepository;

    public Student updateStudent(Student student) {
        Student updatestudent = studentRepository.findById(student.getId()).get();
        updatestudent.setName(student.getName());
        updatestudent.setAddress(student.getAddress());
        updatestudent.setPhoneNumber(student.getPhoneNumber());
        return studentRepository.save(updatestudent);
    }

    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }

    public Student getstudentById(Long id) {
        Optional<Student> program =studentRepository.findById(id);
        return  program.get();
    }

    public List<Student> getallstudent() {
        return studentRepository.findAll();
    }

    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }
    
    
}
